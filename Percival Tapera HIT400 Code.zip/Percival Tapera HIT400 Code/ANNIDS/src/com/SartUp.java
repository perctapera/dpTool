package com;

import com.neuralnet.engine.SevenFeatures;

public class SartUp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		/*SevenFeatures sevenFeatures = new SevenFeatures();
		sevenFeatures.train();
		System.out.println("System has been trained");
		sevenFeatures.run();
		*/
			
			float w = 75;
			float h = 150/100;
			

			float bmi = w/(h*h);

			System.out.print(bmi);
		}
	}

