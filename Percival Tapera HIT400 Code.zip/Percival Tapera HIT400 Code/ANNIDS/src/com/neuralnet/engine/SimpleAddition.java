package com.neuralnet.engine;

public class SimpleAddition {
	

}
