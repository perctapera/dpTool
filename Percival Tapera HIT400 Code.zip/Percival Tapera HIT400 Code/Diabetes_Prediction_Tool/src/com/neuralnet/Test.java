package com.neuralnet;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println("-----------------------------------");
		float notpNorm =   (float)5/17;
		
		
		System.out.println(notpNorm);
		
	}

}
