/**
 * 
 */
/**
 * @author PercTapera
 *
 */
package com.neuralnet.engine;