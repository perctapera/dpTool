package com.neuralnet.engine;

public interface EngineInterface {

	public void run(double[][] vector);
}
