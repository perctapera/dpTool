/**
 * 
 */
/**
 * @author PercTapera
 *
 */
package com.neuralnet;