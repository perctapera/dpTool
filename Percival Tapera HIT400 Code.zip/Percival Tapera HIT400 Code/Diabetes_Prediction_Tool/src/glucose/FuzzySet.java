package glucose;

public class FuzzySet {

	public double evaluate(double in) {
		// TODO Auto-generated method stub
		return 0;
	}

}
