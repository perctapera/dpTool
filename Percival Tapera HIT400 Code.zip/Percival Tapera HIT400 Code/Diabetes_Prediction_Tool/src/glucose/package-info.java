/**
 * 
 */
/**
 * @author PercTapera
 *
 */
package glucose;