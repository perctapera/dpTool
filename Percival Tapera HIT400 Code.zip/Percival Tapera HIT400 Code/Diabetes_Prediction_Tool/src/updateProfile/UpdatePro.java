package updateProfile;

public class UpdatePro {
private int id;
private String fullname;
private String surname;
private int sex;
private float weight;
private float bmi;
private int age;
private int iffp;
private int bp;
private float dpf;
private float sugar;
private int fk_user;
private int height;

public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getFullname() {
	return fullname;
}
public void setFullname(String fullname) {
	this.fullname = fullname;
}
public String getSurname() {
	return surname;
}
public void setSurname(String surname) {
	this.surname = surname;
}
public int getSex() {
	return sex;
}
public void setSex(int sex) {
	this.sex = sex;
}
public float getWeight() {
	return weight;
}
public void setWeight(float weight) {
	this.weight = weight;
}
public float getBmi() {
	return bmi;
}
public void setBmi(float bmi) {
	this.bmi = bmi;
}
public int getAge() {
	return age;
}
public void setAge(int age) {
	this.age = age;
}
public int getIffp() {
	return iffp;
}
public void setIffp(int iffp) {
	this.iffp = iffp;
}
public int getBp() {
	return bp;
}
public void setBp(int bp) {
	this.bp = bp;
}
public float getDpf() {
	return dpf;
}
public void setDpf(float dpf) {
	this.dpf = dpf;
}
public float getSugar() {
	return sugar;
}
public void setSugar(float sugar) {
	this.sugar = sugar;
}
public int getFk_user() {
	return fk_user;
}
public void setFk_user(int fk_user) {
	this.fk_user = fk_user;
}
public int getHeight() {
	return height;
}
public void setHeight(int height) {
	this.height = height;
}
}