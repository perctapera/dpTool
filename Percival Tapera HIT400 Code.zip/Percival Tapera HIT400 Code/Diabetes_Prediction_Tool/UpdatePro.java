package updateProfile;

public class UpdatePro {
private int id;
private String fullname;
private String surname;
private int sex;
private int weight;
private int bmi;
private int age;
private int iffp;
private int bp;
private int dpf;
private int sugar;
private int user_id;
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getFullname() {
	return fullname;
}
public void setFullname(String fullname) {
	this.fullname = fullname;
}
public String getSurname() {
	return surname;
}
public void setSurname(String surname) {
	this.surname = surname;
}
public int getSex() {
	return sex;
}
public void setSex(int sex) {
	this.sex = sex;
}
public int getWeight() {
	return weight;
}
public void setWeight(int weight) {
	this.weight = weight;
}
public int getBmi() {
	return bmi;
}
public void setBmi(int bmi) {
	this.bmi = bmi;
}
public int getAge() {
	return age;
}
public void setAge(int age) {
	this.age = age;
}
public int getIffp() {
	return iffp;
}
public void setIffp(int iffp) {
	this.iffp = iffp;
}
public int getBp() {
	return bp;
}
public void setBp(int bp) {
	this.bp = bp;
}
public int getDpf() {
	return dpf;
}
public void setDpf(int dpf) {
	this.dpf = dpf;
}
public int getSugar() {
	return sugar;
}
public void setSugar(int sugar) {
	this.sugar = sugar;
}
public int getUser_id() {
	return user_id;
}
public void setUser_id(int user_id) {
	this.user_id = user_id;
}

}
